<?php

return [
    'tables' => [
        // table names for generating bread seeders.
        'data_rows',
        'data_types',
        'menus',
        'menu_items',
        'permissions',
        'permission_role',
        'roles',
        'settings',
        'translations',
    ],
];
