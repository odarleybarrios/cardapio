<?php

namespace App\Models;

use TCG\Voyager\Facades\Voyager;


class Permission extends \TCG\Voyager\Models\Permission
{

}
