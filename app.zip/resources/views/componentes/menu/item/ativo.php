<li class="nav-item">
    <a class="nav-link active" aria-current="page" href="{{ url('/') }}">Home</a>
</li>
