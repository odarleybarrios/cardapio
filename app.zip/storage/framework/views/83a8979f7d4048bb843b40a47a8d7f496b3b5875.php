<?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('voyager.login')): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('voyager.login')); ?>"><?php echo e(__('Login')); ?></a>
        </li>
    <?php endif; ?>

    <?php if(Route::has('register')): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
        </li>
    <?php endif; ?>
<?php else: ?>
    <li class="nav-item dropdown">
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(Auth::user()->name); ?>

        </a>

        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('voyager.dashboard')); ?>">
                dashboard
            </a>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </li>
<?php endif; ?>
<?php /**PATH C:\projetos\cardapio\resources\views/componentes/menu/item/login.blade.php ENDPATH**/ ?>