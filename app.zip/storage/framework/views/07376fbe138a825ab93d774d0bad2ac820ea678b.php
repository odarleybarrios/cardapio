<header class="masthead">
    <div class="container">
        <div class="masthead-subheading">
           <?php echo e(setting('site.title')); ?>

        </div>
        <div class="masthead-heading text-uppercase">
            <?php echo e(setting('site.description')); ?>

        </div>
        <a class="btn btn-primary btn-xl text-uppercase" href="#services">
            <?php echo e($botao ?? 'Conheça a aplicação'); ?>

        </a>
    </div>
</header>
<?php /**PATH C:\Users\ifms.DELLISSUES\Downloads\projeto-base-voyager-main\resources\views/templates/header.blade.php ENDPATH**/ ?>