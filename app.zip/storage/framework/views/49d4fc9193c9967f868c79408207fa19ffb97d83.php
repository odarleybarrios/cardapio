<?php $__env->startSection('conteudo'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ALUNO.DESKTOP-549A1KR\Downloads\projeto-laravel-voyager-sqlite\resources\views/welcome.blade.php ENDPATH**/ ?>