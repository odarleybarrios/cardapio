<div class="card" style="width: 18rem;">
    <img src="<?php echo e(@asset('assets/images/exemplos/2.jpg')); ?>" class="card-img-top" alt="...">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($post->title); ?></h5>
        <p class="card-text">
            <?php echo e($post->excerpt); ?>

        </p>
        <a href="#" class="btn btn-primary">Ler</a>
    </div>
</div>
<?php /**PATH C:\Users\ALUNO.DESKTOP-549A1KR\Downloads\projeto-laravel-voyager-sqlite\resources\views/componentes/card.blade.php ENDPATH**/ ?>