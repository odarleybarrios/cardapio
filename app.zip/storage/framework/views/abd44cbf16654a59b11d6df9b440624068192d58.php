<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php if(config('env') == 'local'): ?>
    <link rel="stylesheet" href="<?php echo e(secure_asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(secure_asset('/vendor/font-awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(secure_asset('assets/css/app.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/vendor/font-awesome/css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <?php endif; ?>
    <?php echo $__env->yieldContent('assets'); ?>
</head>

<body id="page-top" class="d-flex flex-column vh-100">

    <?php $__env->startSection('menu'); ?>
        <?php if ($__env->exists('componentes.menu.publico')) echo $__env->make('componentes.menu.publico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>

    <main class="flex-grow-1">
        <?php echo $__env->yieldContent('conteudo'); ?>
    </main>
    <?php $__env->startSection('secao'); ?>
        <section class="page-section">
            <?php echo $__env->yieldContent('page-section'); ?>
        </section>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('rodape'); ?>

        <!-- Footer-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">Copyright © <?php echo e(env('APP_NAME')); ?></div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Github">
                            <i class="fab fa-github"></i>
                        </a>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                        <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>
    <?php echo $__env->yieldSection(); ?>
    <?php if(config('env') == 'local'): ?>
    <script src="<?php echo e(secure_asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(secure_asset('assets/js/app.js')); ?>></script>
    <?php else: ?>
    <script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>></script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\projetos\cardapio\resources\views/layouts/app.blade.php ENDPATH**/ ?>